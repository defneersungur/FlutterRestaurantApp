class Recipe {
  final String id;
  final String name;
  final List<String> ingredients;
  final String steps;
  final String imageUrl;
  final String category; // Yeni eklenen alan
  

  Recipe({
    required this.id,
    required this.name,
    required this.ingredients,
    required this.steps,
    required this.imageUrl,
    required this.category,
   
  });

  factory Recipe.fromFirestore(Map<String, dynamic> data, String id) {
  return Recipe(
    id: id,
    name: data['name'] ?? '',
    ingredients: List<String>.from(data['ingredients'] ?? []),
    steps: data['steps'] ?? '',
    imageUrl: data['imageUrl'] ?? '',
    category: data['category'] ?? '',
    
  );
}

}
