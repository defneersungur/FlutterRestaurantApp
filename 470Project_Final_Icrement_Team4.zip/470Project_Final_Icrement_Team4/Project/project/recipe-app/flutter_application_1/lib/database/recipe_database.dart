import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../models/recipe.dart';
import 'dart:io' show Platform;


class RecipeDatabase {
  static Database? _db;

  static Future<Database> get database async {
  if (!Platform.isAndroid && !Platform.isIOS) {
    throw Exception("SQLite only supported on Android and iOS");
  }
  if (_db != null) return _db!;
  _db = await _initDB('recipes.db');
  return _db!;
}


  static Future<Database> _initDB(String fileName) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, fileName);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  static Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE recipes (
        id TEXT PRIMARY KEY,
        name TEXT,
        ingredients TEXT,
        steps TEXT,
        imageUrl TEXT,
        category TEXT
      )
    ''');
  }

  static Future<void> insertRecipe(Recipe recipe) async {
    final db = await database;
    await db.insert('recipes', {
      'id': recipe.id,
      'name': recipe.name,
      'ingredients': recipe.ingredients.join(','),
      'steps': recipe.steps,
      'imageUrl': recipe.imageUrl,
      'category': recipe.category,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<List<Recipe>> getAllRecipes() async {
    final db = await database;
    final result = await db.query('recipes');

    return result.map((e) => Recipe(
      id: e['id'] as String,
      name: e['name'] as String,
      ingredients: (e['ingredients'] as String).split(','),
      steps: e['steps'] as String,
      imageUrl: e['imageUrl'] as String,
      category: e['category'] as String,
    )).toList();
  }
  static Future<void> printAllRecipes() async {
    final db = await database;
    final result = await db.query('recipes');

    print('📦 Local SQLite Tarifi Sayısı: ${result.length}');
    for (var row in result) {
      print('🧾 Tarif: $row');
    }
  }
}
