import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_application_1/models/recipe.dart';
import '../custom_widgets/recipe_card.dart';
import '../custom_widgets/recipe_detail_dialog.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isHovered = false;

String searchText = '';


  String selectedCategory = "ALL";
  final List<String> categories = ["ALL", "Pasta", "Pizza", "Dessert"];
  
  // kategori adlarına uygun ikonlar
final Map<String, IconData> categoryIcons = {
  'ALL': Icons.grid_view,
  'Pasta': Icons.rice_bowl,
  'Pizza': Icons.local_pizza,
  'Dessert': Icons.cake_outlined,
};


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: PreferredSize(
  preferredSize: const Size.fromHeight(80),
  child: AppBar(
    automaticallyImplyLeading: false,
    backgroundColor: Color(0xFFF5F5F5) ,
    elevation: 0,
    centerTitle: true,
    title: Text(
      'Embark on Your Cooking Journey',
      style: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.normal,
        color: Colors.teal[900],
      ),
    ),
    actions: [
      IconButton(
        icon: const Icon(Icons.logout, color: Color.fromARGB(255, 1, 78, 70)),
        tooltip: 'Logout',
        onPressed: () async {
          await FirebaseAuth.instance.signOut();
          Navigator.pushReplacementNamed(context, '/login');
        },
      ),
    ],
  ),
),


      body: Column(
        children: [
          // Category Filter
   Container(
  height: 45,
  padding: const EdgeInsets.symmetric(horizontal: 8.0),
  child: ListView.builder(
    scrollDirection: Axis.horizontal,
    itemCount: categories.length,
    itemBuilder: (context, index) {
      final category = categories[index];
      final isSelected = selectedCategory == category;

      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4.0),
        child: GestureDetector(
          onTap: () => setState(() => selectedCategory = category),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeInOut,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: isSelected ? Colors.white : Colors.teal[900],
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.teal[900]!),
              boxShadow: isSelected
                  ? [BoxShadow(color: Colors.black12, blurRadius: 4)]
                  : [],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  categoryIcons[category] ?? Icons.category,
                  size: 18,
                  color: isSelected ? Colors.teal[900] : Colors.white,
                ),
                const SizedBox(width: 6),
                Text(
                  category,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                    color: isSelected ? Colors.teal[900] : Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  ),
),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
  child: TextField(
    decoration: InputDecoration(
      hintText: 'Search recipes by name...',
      prefixIcon: Icon(Icons.search),
      filled: true,
      fillColor: Colors.white,
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Color.fromARGB(255, 1, 78, 70), width: 2),
      ),
    ),
    onChanged: (value) {
      setState(() {
        searchText = value.toLowerCase();
      });
    },
  ),
),



          // Recipes List
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('recipes').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final docs = snapshot.data!.docs;
               final allRecipes = docs.map((doc) => Recipe.fromFirestore(doc.data() as Map<String, dynamic>, doc.id)).toList();

final filteredRecipes = allRecipes.where((r) {
  final matchesCategory = selectedCategory == "ALL" ||
      r.category.trim().toLowerCase() == selectedCategory.toLowerCase();
  final matchesSearch = r.name.toLowerCase().contains(searchText);
  return matchesCategory && matchesSearch;
}).toList();

                return ListView.builder(
                  itemCount: filteredRecipes.length,
                  itemBuilder: (context, index) {
                    final recipe = filteredRecipes[index];
                    return GestureDetector(
                      onTap: () => showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return RecipeDetailDialog(recipe: recipe);
                        },
                      ),
                      child: RecipeCard(recipe: recipe),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),

      // Buttons: My Recipes + Add Recipe
    floatingActionButton: Stack(
  children: [
    Align(
      alignment: Alignment.bottomLeft,
      child: Padding(
        padding: const EdgeInsets.only(left: 30.0, bottom: 20),
        child: SizedBox(
          width: 100,
          height: 38,
          child: FloatingActionButton(
            heroTag: "myRecipes",
            backgroundColor: Colors.teal[900],
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(9), // kareye yakın
            ),
            onPressed: () {
              Navigator.pushNamed(context, '/myRecipes');
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.person, size: 18, color: Colors.white),
                SizedBox(width: 6),
                Text(
                  "My Recipes",
                  style: TextStyle(fontSize: 12, color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
    Align(
      alignment: Alignment.bottomRight,
      child: Padding(
        padding: const EdgeInsets.only(right: 16.0, bottom: 20),
        child: SizedBox(
          width: 70,
          height: 38,
          child: FloatingActionButton(
            heroTag: "addRecipe",
            backgroundColor: Colors.teal[900],
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(9),
            ),
            onPressed: () async {
              await Navigator.pushNamed(context, '/addRecipe');
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.add, size: 18, color: Colors.white),
                SizedBox(width: 6),
                Text(
                  "Add",
                  style: TextStyle(fontSize: 12, color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  ],
),


    );
  }
}
