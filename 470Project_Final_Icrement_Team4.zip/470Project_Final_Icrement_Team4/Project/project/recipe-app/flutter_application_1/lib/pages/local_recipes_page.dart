import 'package:flutter/material.dart';
import '../models/recipe.dart';
import '../database/recipe_database.dart';
import '../custom_widgets/recipe_card.dart';
import '../custom_widgets/recipe_detail_dialog.dart';

class LocalRecipesPage extends StatefulWidget {
  const LocalRecipesPage({Key? key}) : super(key: key);

  @override
  State<LocalRecipesPage> createState() => _LocalRecipesPageState();
}

class _LocalRecipesPageState extends State<LocalRecipesPage> {
  List<Recipe> localRecipes = [];

  @override
  void initState() {
    super.initState();
    loadLocalRecipes();
  }

  Future<void> loadLocalRecipes() async {
    final recipes = await RecipeDatabase.getAllRecipes();
    setState(() {
      localRecipes = recipes;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Offline Recipes'),
        backgroundColor: Colors.teal,
      ),
      body: localRecipes.isEmpty
          ? const Center(child: Text('No local recipes found.'))
          : ListView.builder(
              itemCount: localRecipes.length,
              itemBuilder: (context, index) {
                final recipe = localRecipes[index];
                return GestureDetector(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) => RecipeDetailDialog(recipe: recipe),
                    );
                  },
                  child: RecipeCard(recipe: recipe),
                );
              },
            ),
    );
  }
}
