import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_application_1/models/recipe.dart';
import '../custom_widgets/recipe_card.dart';
import '../custom_widgets/recipe_detail_dialog.dart';

class MyRecipesPage extends StatefulWidget {
  const MyRecipesPage({Key? key}) : super(key: key);

  @override
  State<MyRecipesPage> createState() => _MyRecipesPageState();
}

class _MyRecipesPageState extends State<MyRecipesPage> {
  final List<String> _categories = ['Pasta', 'Pizza', 'Dessert'];
  late Stream<QuerySnapshot> _recipesStream;

  @override
  void initState() {
    super.initState();
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      _recipesStream = FirebaseFirestore.instance
          .collection('recipes')
          .where('uid', isEqualTo: uid)
          .snapshots();
    }
  }

  Future<void> deleteRecipe(String id) async {
    await FirebaseFirestore.instance.collection('recipes').doc(id).delete();
  }

  Future<void> showEditDialog(Recipe recipe) async {
    final _formKey = GlobalKey<FormState>();
    final nameController = TextEditingController(text: recipe.name);
    final ingredientsController = TextEditingController(text: recipe.ingredients.join(', '));
    final stepsController = TextEditingController(text: recipe.steps);
    final imageUrlController = TextEditingController(text: recipe.imageUrl);
    String category = recipe.category;

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Recipe'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Name'),
                ),
                TextFormField(
                  controller: ingredientsController,
                  decoration: const InputDecoration(labelText: 'Ingredients (comma separated)'),
                ),
                TextFormField(
                  controller: stepsController,
                  decoration: const InputDecoration(labelText: 'Preparation Steps'),
                  maxLines: 3,
                ),
                DropdownButtonFormField<String>(
                  value: _categories.contains(category) ? category : _categories[0],
                  decoration: const InputDecoration(labelText: 'Category'),
                  items: _categories.map((cat) => DropdownMenuItem(value: cat, child: Text(cat))).toList(),
                  onChanged: (value) => category = value ?? category,
                ),
                TextFormField(
                  controller: imageUrlController,
                  decoration: const InputDecoration(labelText: 'Image URL'),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.red),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              final updatedRecipe = Recipe(
                id: recipe.id,
                name: nameController.text,
                ingredients: ingredientsController.text.split(',').map((e) => e.trim()).toList(),
                steps: stepsController.text,
                category: category,
                imageUrl: imageUrlController.text,
              );

              await FirebaseFirestore.instance
                  .collection('recipes')
                  .doc(recipe.id)
                  .update({
                'name': updatedRecipe.name,
                'ingredients': updatedRecipe.ingredients,
                'steps': updatedRecipe.steps,
                'category': updatedRecipe.category,
                'imageUrl': updatedRecipe.imageUrl,
              });

              Navigator.of(context).pop();
            },
            child: const Text(
              'Save',
              style: TextStyle(color: Colors.green),
            ),
          ),
        ],
      ),
    );
  }

 @override
Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: const Color(0xFFF5F5F5), // Body arka planı gri
    appBar: AppBar(
      backgroundColor: const Color(0xFFF5F5F5), // AppBar da gri
      elevation: 0,
      centerTitle: true,
      title: const Text(
        "My Recipes",
        style: TextStyle(
          color: Color.fromARGB(255, 1, 78, 70), // Yazı rengi yeşil
          fontWeight: FontWeight.bold,
          fontSize: 22,
        ),
      ),
      iconTheme: const IconThemeData(color: Color.fromARGB(255, 1, 78, 70)), // Geri butonu rengi yeşil
    ),
    body: StreamBuilder<QuerySnapshot>(
      stream: _recipesStream,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;
        final myRecipes = docs
            .map((doc) => Recipe.fromFirestore(doc.data() as Map<String, dynamic>, doc.id))
            .toList();

        if (myRecipes.isEmpty) {
          return const Center(
            child: Text(
              "No recipes found.",
              style: TextStyle(fontSize: 16),
            ),
          );
        }

        return ListView.builder(
          itemCount: myRecipes.length,
          itemBuilder: (context, index) {
            final recipe = myRecipes[index];
            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: ListTile(
                title: Text(
                  recipe.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                subtitle: Text(recipe.category),
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => RecipeDetailDialog(recipe: recipe),
                ),
                trailing: Wrap(
                  spacing: 12,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Color.fromARGB(255, 1, 78, 70)), // Kalem ikonu yeşil
                      onPressed: () => showEditDialog(recipe),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Color.fromARGB(255, 192, 36, 25)),
                      onPressed: () => deleteRecipe(recipe.id),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    ),
  );
}

}