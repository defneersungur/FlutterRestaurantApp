import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/recipe.dart';
import 'package:flutter_application_1/utils/utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';

class AddRecipePage extends StatefulWidget {
  const AddRecipePage({Key? key}) : super(key: key);

  @override
  _AddRecipePageState createState() => _AddRecipePageState();
}

class _AddRecipePageState extends State<AddRecipePage> {
  final _formKey = GlobalKey<FormState>();
  String? _name;
  String? _ingredients;
  String? _steps;
  String? _selectedCategory;
  String? _imageUrlText;

  final List<String> _categories = ['Pasta', 'Pizza', 'Dessert'];

  @override
  void initState() {
    super.initState();
    _selectedCategory = _categories[0];
  }

  void _saveRecipe() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      final imageUrl = _imageUrlText?.trim().isNotEmpty == true ? _imageUrlText!.trim() : 'https://picsum.photos/200';
      final currentUser = FirebaseAuth.instance.currentUser;

      if (currentUser == null) {
        showError(context, 'No user logged in.');
        return;
      }

      Recipe newRecipe = Recipe(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: _name!,
        ingredients: _ingredients!.split(',').map((e) => e.trim()).toList(),
        steps: _steps!,
        imageUrl: imageUrl,
        category: _selectedCategory!,
      );

      try {
        await FirebaseFirestore.instance
            .collection('recipes')
            .doc(newRecipe.id)
            .set({
          'name': newRecipe.name,
          'ingredients': newRecipe.ingredients,
          'steps': newRecipe.steps,
          'imageUrl': newRecipe.imageUrl,
          'category': newRecipe.category,
          'uid': currentUser.uid,
        });

        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: Color.fromARGB(255, 1, 78, 70),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              content: Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Successfully added to Firestore!',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                   ElevatedButton(
  onPressed: () {
    Navigator.of(context).pop(); // dialogu kapat
    Navigator.pushReplacementNamed(context, '/home'); // HomePage'e yönlendir
  },
  style: ElevatedButton.styleFrom(
    backgroundColor: Colors.white,
    foregroundColor: Color.fromARGB(255, 1, 78, 70),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8),
    ),
  ),
  child: const Text('OK'),
),

                  ],
                ),
              ),
            );
          },
        );
      } catch (e) {
        showError(context, 'Failed to save: $e');
      }
    } else {
      showError(context, 'Please fill all fields');
    }
  }

  @override
Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: const Color(0xFFF5F5F5),
    appBar: AppBar(
      automaticallyImplyLeading: true,
      backgroundColor:  const Color(0xFFF5F5F5),
      elevation: 0,
      centerTitle: true,
      title: const Text(
        'Add New Recipe',
        style: TextStyle(
         
          fontSize: 22,
          fontWeight: FontWeight.bold,
          color: Color.fromARGB(255, 1, 78, 70),
        ),
      ),
      iconTheme: const IconThemeData(color: Color.fromARGB(255, 1, 78, 70))
    ),
    body: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Recipe Name
              TextFormField(
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  labelText: 'Recipe Name',
                  labelStyle: const TextStyle(color: Color.fromARGB(255, 1, 78, 70)),
                  prefixIcon: const Icon(Icons.restaurant_menu, color: Color.fromARGB(255, 1, 78, 70)),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  hoverColor: Colors.transparent,
                ),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Please enter recipe name' : null,
                onSaved: (value) => _name = value,
              ),
              const SizedBox(height: 16),

              // Ingredients
              TextFormField(
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  labelText: 'Ingredients (separate with commas)',
                  labelStyle: const TextStyle(color: Color.fromARGB(255, 1, 78, 70)),
                  prefixIcon: const Icon(Icons.shopping_bag, color: Color.fromARGB(255, 1, 78, 70)),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  hoverColor: Colors.transparent,
                ),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Please enter ingredients' : null,
                onSaved: (value) => _ingredients = value,
              ),
              const SizedBox(height: 16),

              // Preparation Steps
              TextFormField(
                maxLines: 3,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  labelText: 'Preparation Steps',
                  labelStyle: const TextStyle(color:Color.fromARGB(255, 1, 78, 70)),
                  prefixIcon: const Icon(Icons.list_alt, color: Color.fromARGB(255, 1, 78, 70)),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  hoverColor: Colors.transparent,
                ),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Please enter preparation steps' : null,
                onSaved: (value) => _steps = value,
              ),
              const SizedBox(height: 16),

              // Category Dropdown
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  labelText: 'Select Category',
                  labelStyle: const TextStyle(color: Color.fromARGB(255, 1, 78, 70)),
                  prefixIcon: const Icon(Icons.category, color: Color.fromARGB(255, 1, 78, 70)),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
                dropdownColor: Colors.white,
                value: _selectedCategory,
                items: _categories
                    .map((category) => DropdownMenuItem(
                          value: category,
                          child: Text(
                            category,
                            style: const TextStyle(color: Color.fromARGB(255, 1, 78, 70)),
                          ),
                        ))
                    .toList(),
                onChanged: (value) => setState(() => _selectedCategory = value),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Please select a category' : null,
              ),
              const SizedBox(height: 16),

              // Image URL
              TextFormField(
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  labelText: 'Image URL (for web)',
                  labelStyle: const TextStyle(color: Color.fromARGB(255, 1, 78, 70)),
                  prefixIcon: const Icon(Icons.image, color: Color.fromARGB(255, 1, 78, 70)),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  hoverColor: Colors.transparent,
                ),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Please enter image URL' : null,
                onSaved: (value) => _imageUrlText = value,
              ),
              const SizedBox(height: 24),

              // Save Button
              SizedBox(
                  width: 140,
                child: ElevatedButton(
                  onPressed: _saveRecipe,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal[900],
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    textStyle:
                        const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
    "Save Recipe",
    style: GoogleFonts.lora(
      fontSize: 16,
      fontWeight: FontWeight.w600,
      color: Colors.white,
    ),
  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

}