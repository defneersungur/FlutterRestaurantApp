import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/firebase_sync.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  String? _email;
  String? _password;
  bool _obscurePassword = true;
  bool _logoVisible = false;

  @override
void initState() {
  super.initState();
  Future.delayed(Duration(milliseconds: 200), () {
    setState(() {
      _logoVisible = true;
    });
  });
}



  void _login() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      try {
        // Firebase ile giriş yap
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _email!,
          password: _password!,
        );

        // Giriş başarılı
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Login Successful')),
        );
        Navigator.pushReplacementNamed(context, '/home');
      } on FirebaseAuthException catch (e) {
        String errorMessage;

        switch (e.code) {
          case 'user-not-found':
            errorMessage = 'User not found.';
            break;
          case 'wrong-password':
            errorMessage = 'Incorrect password.';
            break;
          default:
            errorMessage = 'Login failed. ${e.message}';
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(errorMessage)),
        );
      } catch (e) {
        // Firebase dışı hata
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Unexpected error: $e')),
        );
      }
    }
  }

 @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal[900],
      appBar: AppBar(
        backgroundColor: Colors.teal[900],
        elevation: 0,
        centerTitle: true,
        toolbarHeight: 120,
        automaticallyImplyLeading: false,
        title: AnimatedOpacity(
  opacity: _logoVisible ? 1.0 : 0.0,
  duration: Duration(milliseconds: 600),
  child: AnimatedScale(
    scale: _logoVisible ? 1.0 : 0.6,
    duration: Duration(milliseconds: 600),
    curve: Curves.easeOutBack,
    child: Image.asset(
      'assets/images/whitelogo.png',
      height: 150,
      fit: BoxFit.contain,
    ),
  ),
),

      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              const Text(
                'Find Your Next Favorite Dish with Tasty',
                style: TextStyle(
                  fontSize: 26,
                  color: Colors.white,
                  fontWeight: FontWeight.normal,
                ),
              ),
              const SizedBox(height: 40),

              // EMAIL FIELD
              TextFormField(
                cursorColor: Colors.white,
  decoration: InputDecoration(
    labelText: 'Email',
    labelStyle: const TextStyle(color: Colors.white),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Colors.white),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Colors.white),
    ),
    errorStyle: const TextStyle(
      color: Colors.white,
      fontStyle: FontStyle.italic,
    ),
  ),
  style: const TextStyle(color: Colors.white),
  validator: (value) {
    if (value == null || value.isEmpty) {
      return 'Please enter an email';
    }
    return null;
  },
  onSaved: (value) => _email = value,
),


              const SizedBox(height: 20),

              // PASSWORD FIELD
             TextFormField(
              cursorColor: Colors.white,
  decoration: InputDecoration(
    labelText: 'Password',
    labelStyle: const TextStyle(color: Colors.white),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Colors.white),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Colors.white),
    ),
    errorStyle: const TextStyle(
      color: Colors.white,
      fontStyle: FontStyle.italic,
    ),
    suffixIcon: IconButton(
      icon: Icon(
        _obscurePassword ? Icons.visibility_off : Icons.visibility,
        color: Colors.white,
      ),
      onPressed: () {
        setState(() {
          _obscurePassword = !_obscurePassword;
        });
      },
    ),
  ),
  style: const TextStyle(color: Colors.white),
  obscureText: _obscurePassword,
  validator: (value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a password';
    }
    return null;
  },
  onSaved: (value) => _password = value,
),


              const SizedBox(height: 40),

              // LOGIN BUTTON
              Center(
                child: ElevatedButton(
                  onPressed: _login,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.teal[900],
                    padding: const EdgeInsets.symmetric(
                        horizontal: 50, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  child: const Text(
                    'Login',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // REGISTER TEXT BUTTON
              Center(
                child: TextButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/register');
                  },
                  child: const Text(
                    'Don\'t have an account? Register',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

}
