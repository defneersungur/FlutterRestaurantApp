import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/recipe.dart';

class RecipeCard extends StatelessWidget {
  final Recipe recipe;

  const RecipeCard({Key? key, required this.recipe}) : super(key: key);

  Widget _buildImage() {
    final url = recipe.imageUrl;

    // Web platformundaysak sadece network ve asset resimleri desteklenir
    if (kIsWeb) {
      if (url.startsWith('http') || url.startsWith('https')) {
        return Image.network(
          url,
          width: 50,
          height: 50,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) => _placeholderImage(),
        );
      } else if (url.startsWith('assets/')) {
        return Image.asset(
          url,
          width: 50,
          height: 50,
          fit: BoxFit.cover,
        );
      } else {
        return _placeholderImage();
      }
    }

    // Mobil veya masaüstünde ise
    if (url.startsWith('http') || url.startsWith('https')) {
      return Image.network(
        url,
        width: 50,
        height: 50,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => _placeholderImage(),
      );
    } else if (url.startsWith('assets/')) {
      return Image.asset(
        url,
        width: 50,
        height: 50,
        fit: BoxFit.cover,
      );
    } else {
      return Image.file(
        File(url),
        width: 50,
        height: 50,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => _placeholderImage(),
      );
    }
  }

  Widget _placeholderImage() {
    return Container(
      width: 50,
      height: 50,
      color: Colors.grey[300],
      child: const Icon(Icons.broken_image, size: 30, color: Colors.grey),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: ListTile(
        leading: _buildImage(),
        title: Text(
  recipe.name,
  style: const TextStyle(
    fontWeight: FontWeight.bold, // veya FontWeight.w700
    fontSize: 16,
  ),
),

        subtitle: Text('Ingredients: ${recipe.ingredients.join(', ')}'),
      ),
    );
  }
}
