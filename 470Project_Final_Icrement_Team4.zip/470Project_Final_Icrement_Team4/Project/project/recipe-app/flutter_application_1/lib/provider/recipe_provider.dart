import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/recipe.dart';

class RecipeProvider with ChangeNotifier{
  // Örnek tarif listesi
  List<Recipe> _recipes = [];

  List<Recipe> get recipes => _recipes;

  void addRecipe(Recipe recipe) {
    _recipes.add(recipe);
    // Not: Gerçek uygulamada notifyListeners() vs. kullanılacak.
  }
}
