import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart'; // otomatik oluşan dosya
import 'package:google_fonts/google_fonts.dart';

import 'pages/login_page.dart';
import 'pages/register_page.dart';
import 'pages/home_page.dart';
import 'pages/add_recipe_page.dart';
import 'pages/my_recipes_page.dart';
import 'pages/local_recipes_page.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(RecipeApp());
}

class RecipeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My Recipe',
      theme: ThemeData(
        progressIndicatorTheme: ProgressIndicatorThemeData(
    color: Color.fromARGB(255, 1, 78, 70), // global olarak yüklenme rengi
  ),
           textSelectionTheme: const TextSelectionThemeData(
      cursorColor:Color.fromARGB(255, 1, 78, 70), // imleç rengi
      //selectionColor: Color(0xFFB2DFDB), // seçili metin rengi
      //selectionHandleColor: Colors.teal, // tutma noktası
      
    ),
        primarySwatch: Colors.purple,
        scaffoldBackgroundColor: Colors.white,
        colorScheme: const ColorScheme.light(
          secondary: Colors.pinkAccent,
          
        ),
        textTheme: GoogleFonts.loraTextTheme(),
        buttonTheme: const ButtonThemeData(
          buttonColor: Colors.pinkAccent,
          textTheme: ButtonTextTheme.primary,
        ),
      ),
      home: LoginPage(),
      routes: {
        '/home': (context) => HomePage(),
        '/addRecipe': (context) => AddRecipePage(),
        '/login': (context) => LoginPage(),
        '/register': (context) => RegisterPage(),
        '/myRecipes': (context) => MyRecipesPage(),
        '/localRecipes': (context) => LocalRecipesPage(),


      },
    );
  }
}
