import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/recipe.dart';
import '../database/recipe_database.dart';
import 'package:firebase_auth/firebase_auth.dart';


Future<void> syncFirebaseToSQLite() async {
  final uid = FirebaseAuth.instance.currentUser?.uid;
  if (uid == null) return;

  final snapshot = await FirebaseFirestore.instance
      .collection('recipes')
      .where('uid', isEqualTo: uid)
      .get();

  for (var doc in snapshot.docs) {
    final data = doc.data();
    final recipe = Recipe.fromFirestore(data, doc.id);
    await RecipeDatabase.insertRecipe(recipe);
  }
}